//
//  LocalViewController.swift
//  Go-Fit
//
//  Created by Turing on 11/27/22.
//
//

import UIKit
import MapKit
import CoreLocation

var locationsArray : [MKPointAnnotation] = []
var isLocationButtonPressed = false
class LocalViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
 
    @IBAction func btnAddLocation(_ sender: UIButton)
    {
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.delegate = self
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        locationsArray.append(pin)
    }
    var manager = CLLocationManager()

    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            render(location)
        }
    }
    let pin = MKPointAnnotation()
    func render(_ location: CLLocation)
    {
        let coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        mapView.setRegion(region, animated: true)
        let pin = MKPointAnnotation()
        pin.coordinate = coordinate
        mapView.addAnnotation(pin)
    }
        
}


