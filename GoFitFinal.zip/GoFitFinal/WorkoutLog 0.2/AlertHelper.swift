//
//  AlertHelper.swift
//  Go-Fit
//

import Foundation
import UIKit

class AlertHelper {
    func showAlert(fromController controller: UIViewController, title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        controller.present(alert, animated: true, completion: nil)
    }
}
