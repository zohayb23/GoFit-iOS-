//
//  MuscleTableViewCell.swift
//   Go-Fit
//

import UIKit

class MuscleTableViewCell: UITableViewCell {
    
    @IBOutlet weak var muscleNameLabel: UILabel!
    
    var muscleName: String? {
        didSet {
            updateUI()
        }
    }
    
    private func updateUI() {
        if let muscle = muscleName {
            muscleNameLabel.text = muscle
        }
    }

}
