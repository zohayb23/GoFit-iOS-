//
//  LegsHelpViewController.swift
//  Go-Fit
//
//  Created by Zohayb Bhatti on 11/29/22.
//  
//

import UIKit

class LegsHelpViewController: UIViewController {
    @IBOutlet weak var barbellSquats: UIImageView!
    @IBOutlet weak var legExtensions: UIImageView!
    @IBOutlet weak var legPress: UIImageView!
    @IBOutlet weak var calfRaise: UIImageView!
    @IBOutlet weak var legCurl: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image1 = UIImage.gifImageWithName("sqauts")
        barbellSquats.image = image1
        
        let image2 = UIImage.gifImageWithName("extensions")
        legExtensions.image = image2
        
        let image3 = UIImage.gifImageWithName("press")
        legPress.image = image3
        
        let image4 = UIImage.gifImageWithName("calfraises")
        calfRaise.image = image4
        
        let image5 = UIImage.gifImageWithName("legcurl")
        legCurl.image = image5
        }
    

  

}
