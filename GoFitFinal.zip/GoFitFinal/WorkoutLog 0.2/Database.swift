//
//  Database.swift
//  Go-Fit
//

import Foundation
import CoreData

class Database {
    
    static var muscles = [String: [String]]()
    static var exercises = [String: [String]]()
    
    static func loadData() {
        muscles = [
            "Push": ["Bench Press(Barbell)", "Incline Press(Dumbell)", "Chest Flys(Machine)", "Skull Crushers(Bench)", "Tricep Pushdowns(Cable)"],
            
            "Pull": ["Pull-Ups", "Bicep Curl(Barbell)", "Cable Rows(Machine)", "Lat Pulldowns(Machine)", "Hammer Curls(Dumbell)"],
            
            "Leg": ["Barbell Squats", "Leg Extension", "Leg Press", "Calf Raise", "Seated Leg Curl"]
        ]
        for (muscle, exeriseArray) in muscles {
            for exercise in exeriseArray {
                exercises[exercise] = [muscle]
            }
        }
    }
}
