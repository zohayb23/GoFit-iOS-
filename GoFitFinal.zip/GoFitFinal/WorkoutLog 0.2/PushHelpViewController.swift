//
//  PushHelpViewController.swift
//  Go-Fit
//
//  Created by Zohayb Bhatti on 11/29/22.
//  
//

import UIKit

class PushHelpViewController: UIViewController {
    @IBOutlet weak var benchPress: UIImageView!
    @IBOutlet weak var inclinePress: UIImageView!
    @IBOutlet weak var chestFly: UIImageView!
    @IBOutlet weak var skullCrush: UIImageView!
    @IBOutlet weak var tricepPulldowns: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let image1 = UIImage.gifImageWithName("benchpress")
        benchPress.image = image1
        
        let image2 = UIImage.gifImageWithName("incline")
        inclinePress.image = image2
        
        let image3 = UIImage.gifImageWithName("chestfly")
        chestFly.image = image3
        
        let image4 = UIImage.gifImageWithName("skull")
        skullCrush.image = image4
        
        let image5 = UIImage.gifImageWithName("pulldown")
        tricepPulldowns.image = image5
        
    }
   
    
}
