//
//  PullHelpViewController.swift
//  Go-Fit
//
//  Created by Zohayb Bhatti on 11/29/22.
//  
//

import UIKit

class PullHelpViewController: UIViewController {
    @IBOutlet weak var pullGif: UIImageView!
    @IBOutlet weak var barbellBicepGif: UIImageView!
    @IBOutlet weak var cableRowsGif: UIImageView!
    @IBOutlet weak var latPulldownsGif: UIImageView!
    @IBOutlet weak var hammerCurlsGif: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let image1 = UIImage.gifImageWithName("pullups")
        pullGif.image = image1
        
        let image2 = UIImage.gifImageWithName("barbellcurl")
        barbellBicepGif.image = image2
        
        let image3 = UIImage.gifImageWithName("cablerows")
        cableRowsGif.image = image3
        
        let image4 = UIImage.gifImageWithName("latpulldown")
        latPulldownsGif.image = image4
        
        let image5 = UIImage.gifImageWithName("hammercurl")
        hammerCurlsGif.image = image5
        
    }
    
 
}
